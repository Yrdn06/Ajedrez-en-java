/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author yudyp
 */
public class Torre extends Pieza {
    final String tipoPieza = "Torre";

    public Torre(String color,Coordenada posicion) {
        super(color, posicion);
    }
    @Override
    public boolean movimiento_posible(Coordenada destino, Tablero tablero){
        int filaA = this.posicion.getFila();
        int columnaA = this.posicion.getColumna();
        int filaD = destino.getFila();
        int columnaD =destino.getColumna();
        if (filaA == filaD){
            if(columnaA < columnaD){
                for (int i = columnaA+1; i < columnaD; i++) {
                    Coordenada intermedia = new Coordenada(filaA,i);
                    if (tablero.hayPieza(intermedia)){
                        return false;
                    }
                }
                Pieza piezaDestino = tablero.getCasilla(destino);
                return piezaDestino == null || !piezaDestino.getColor().equals(this.color);
            }
            if(columnaA > columnaD){
                for (int i = columnaD+1; i < columnaA; i++) {
                    Coordenada intermedia = new Coordenada(filaA,i);
                    if (tablero.hayPieza(intermedia)){
                        return false;
                    }
                }
                Pieza piezaDestino = tablero.getCasilla(destino);
                return piezaDestino == null || !piezaDestino.getColor().equals(this.color);
            }
        }
        if(columnaA == columnaD){
            if(filaA < filaD){
                for (int i = filaA+1; i < filaD; i++) {
                    Coordenada intermedia = new Coordenada(i,columnaA);
                    if (tablero.hayPieza(intermedia)){
                        return false;
                    }
                }
                return true;
            }
            if(filaA > filaD){
                for (int i = filaD+1; i < filaA; i++) {
                    Coordenada intermedia = new Coordenada(i,columnaA);
                    if (tablero.hayPieza(intermedia)){
                        return false;
                    }
                }
                return true;
            }
            
        }
        return false;
    }
    @Override
    public String toString() {
        return this.color.equals("blanco") ? "T" : "t";
    }
}
