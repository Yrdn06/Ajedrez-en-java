/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author yudyp
 */
public class Alfir extends Pieza{
    final String tipoPieza = "Alfir";

    public Alfir(String color,Coordenada posicion) {
        super(color, posicion);
    }
    @Override
    public boolean movimiento_posible(Coordenada destino, Tablero tablero){
        int filaA = this.posicion.getFila();
        int columnaA = this.posicion.getColumna();
        int filaD = destino.getFila();
        int columnaD =destino.getColumna();
        for (int i = 1; i < 8; i++) {
            if (filaA +i == filaD && columnaA+i == columnaD){
                for (int j = 1; j < i; j++) {
                    Coordenada intermedia = new Coordenada(filaA+j,columnaA+j);
                    if (tablero.hayPieza(intermedia)) return false;
                }
                return tablero.getCasilla(destino) == null || !tablero.getCasilla(destino).getColor().equals(this.color);
            }
            if (filaA -i == filaD && columnaA-i == columnaD){
                for (int j = 1; j < i; j++) {
                    Coordenada intermedia = new Coordenada(filaA-j,columnaA-j);
                    if (tablero.hayPieza(intermedia)) return false;
                }
                return tablero.getCasilla(destino) == null || !tablero.getCasilla(destino).getColor().equals(this.color);
            }    
            if (filaA +i == filaD && columnaA-i == columnaD){
                for (int j = 1; j < i; j++) {
                    Coordenada intermedia = new Coordenada(filaA+j,columnaA-j);
                    if (tablero.hayPieza(intermedia)) return false;
                }
                return tablero.getCasilla(destino) == null || !tablero.getCasilla(destino).getColor().equals(this.color);
            }    
            if (filaA -i == filaD && columnaA+i == columnaD){
                for (int j = 1; j < i; j++) {
                    Coordenada intermedia = new Coordenada(filaA-j,columnaA+j);
                    if (tablero.hayPieza(intermedia)) return false;
                }
                return tablero.getCasilla(destino) == null || !tablero.getCasilla(destino).getColor().equals(this.color);
            }  
        }
        return false;
    }
    @Override
    public String toString() {
        return this.color.equals("blanco") ? "A" : "a";
    }
    
}
