/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author yudyp
 */
public abstract class Pieza {
    protected String color;
    protected Coordenada posicion;

    /**
     *
     * @param color
     * @param posicion
     */
    public Pieza(String color,Coordenada posicion){
        this.color = color;
        this.posicion = posicion;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    public Coordenada getPosicion() {
        return posicion;
    }

    /**
     * @param posicion the posicion to set
     */
    public void setPosicion(Coordenada posicion) {
        this.posicion = posicion;
    }
    public abstract boolean movimiento_posible(Coordenada destino, Tablero tablero);
    
    @Override
    public abstract String toString();
}
