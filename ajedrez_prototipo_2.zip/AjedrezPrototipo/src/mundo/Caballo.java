/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author yudyp
 */
public class Caballo extends Pieza{
    final String tipoPieza = "Caballo";

    public Caballo(String color,Coordenada posicion) {
        super(color, posicion);
    }
    @Override
    public boolean movimiento_posible(Coordenada destino, Tablero tablero){
        int filaA = this.posicion.getFila();
        int columnaA = this.posicion.getColumna();
        int filaD = destino.getFila();
        int columnaD =destino.getColumna();
        Pieza piezaDestino = tablero.getCasilla(destino);
        if (piezaDestino != null){
            if (piezaDestino.getColor().equals(this.color)){
                return false;
            }
        }
        if (filaD == filaA+2 && columnaD == columnaA+1 )return true;
        if (filaD == filaA+2 && columnaD == columnaA-1 )return true;
        if (filaD == filaA+1 && columnaD == columnaA+2 )return true;
        if (filaD == filaA+1 && columnaD == columnaA-2 )return true;
        if (filaD == filaA-2 && columnaD == columnaA-1 )return true;
        if (filaD == filaA-2 && columnaD == columnaA+1 )return true;
        if (filaD == filaA-1 && columnaD == columnaA+2 )return true;
        if (filaD == filaA-1 && columnaD == columnaA-2 )return true;
        return false;
    }
    @Override
    public String toString() {
        return this.color.equals("blanco") ? "C" : "c";
    }
}
