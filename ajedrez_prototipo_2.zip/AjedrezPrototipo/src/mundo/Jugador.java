/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;
import interfaz.Interfaz;
/**
 *
 * @author yudyp
 */
public class Jugador {
    private String nombre;
    private String color;

    public Jugador(String nombre, String color) {
        this.nombre = nombre;
        this.color = color;
    }
    
    public void mover_pieza(Interfaz interfaz, Tablero tablero){
        while(true){
            System.out.println("ingrese las coordenadas de la pieza que desee mover");
            Coordenada inicial = interfaz.pedirCoordenada();
            System.out.println("ingrese las coordeadas de la posicion a la que la desea mover");
            Coordenada llegada = interfaz.pedirCoordenada();
            boolean seMovio = false;
            if (this.color.equals("blanco")){
                for (Pieza pieza : tablero.getPiezasBlancas()) {
                    if (pieza.getPosicion().equals(inicial)){
                        if(pieza.movimiento_posible(llegada, tablero)){
                            if (tablero.hayPieza(llegada)) {
                                Pieza piezaEnDestino = tablero.getCasilla(llegada);
                                if (!piezaEnDestino.getColor().equals(this.color)) {
                                    tablero.eliminarPieza(piezaEnDestino); 
                                    System.out.println("Pieza enemiga capturada");
                                }
                            }
                            System.out.println("la pieza a sido movida");
                            tablero.setPiezaEnCasilla(llegada, pieza);
                            tablero.quitarPiezaEnCasilla(inicial);
                            pieza.setPosicion(llegada);
                            seMovio = true;
                            break;
                        }
                    }
                } 
            }else{
                for (Pieza pieza : tablero.getPiezasNegras()) {
                    if (pieza.getPosicion().equals(inicial)){
                        if(pieza.movimiento_posible(llegada, tablero)){
                            if (tablero.hayPieza(llegada)) {
                                Pieza piezaEnDestino = tablero.getCasilla(llegada);
                                if (!piezaEnDestino.getColor().equals(this.color)) {
                                    tablero.eliminarPieza(piezaEnDestino); 
                                    System.out.println("Pieza enemiga capturada");
                                }
                            }
                            System.out.println("la pieza a sido movida");
                            tablero.setPiezaEnCasilla(llegada, pieza);
                            tablero.quitarPiezaEnCasilla(inicial);
                            pieza.setPosicion(llegada);
                            seMovio = true;
                            break;
                        }
                    }
                } 
            }
            if (seMovio){
                    break;
            }else{
                System.out.println("coordenada incorrecta o pieza no seleccionada, vuelve a tirar");
            }
        }
    }
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }  
}
