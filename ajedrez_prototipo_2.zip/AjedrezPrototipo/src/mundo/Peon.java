/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author yudyp
 */
public class Peon extends Pieza{
    public Peon(String color,Coordenada posicion) {
        super(color, posicion);
    }
    @Override
    public boolean movimiento_posible(Coordenada destino, Tablero tablero){
        int filaA = this.posicion.getFila();
        int columnaA = this.posicion.getColumna();
        int filaD = destino.getFila();
        int columnaD =destino.getColumna();
        int direccion = this.color.equals("blanco") ? 1 : -1;
        // movimiento de 1
        if (columnaD == columnaA && filaD == filaA + direccion) {
            return !tablero.hayPieza(destino);
        }
        // movimiento de 2
        if (columnaD == columnaA) {
            boolean enInicio = (this.color.equals("blanco") && filaA == 1) || (this.color.equals("negro") && filaA == 6);
            if (enInicio && filaD == filaA + 2 * direccion) {
                Coordenada intermedia = new Coordenada((filaA + direccion), columnaA);
                return !tablero.hayPieza(intermedia) && !tablero.hayPieza(destino);
            }
        }

        // Captura diagonal,math abs es para obtener el valor absosluto, osea lo devuelve en positivo asi de negativo
        if (Math.abs(columnaD - columnaA) == 1 && filaD == filaA + direccion) {
            Pieza piezaEnDestino = tablero.getCasilla(destino);
            return piezaEnDestino != null && !piezaEnDestino.color.equals(this.color);
        }
        return false;
    }
    @Override
    public String toString() {
        return this.color.equals("blanco") ? "P" : "p";
    }
}
