/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author yudyp
 */
public class Rey extends Pieza{
    public Rey(String color,Coordenada posicion) {
        super(color, posicion);
    }
    @Override
    public boolean movimiento_posible(Coordenada destino, Tablero tablero){
        return true;
    }
    @Override
    public String toString() {
        return this.color.equals("blanco") ? "K" : "k";
    }
}
