/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;
import java.util.ArrayList;
/**
 *
 * @author yudyp
 */
public class Tablero {
    private Pieza casillas[][];
    private ArrayList<Pieza> piezasBlancas;
    private ArrayList<Pieza> piezasNegras;
    public Tablero(){
        casillas = new Pieza[8][8];
        piezasBlancas = new ArrayList<Pieza>();
        piezasNegras = new ArrayList<Pieza>();
        inicializarTablero();
        colocarPiezas();
        
    }
    public void inicializarTablero(){
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 casillas[i][j] = null;
            }
        }
    }
    public void colocarPiezas(){
        //blancas
        for (int i = 0; i < 8; i++) {
            Pieza peon = new Peon("blanco",new Coordenada(1,i));
            casillas[1][i] = peon;
            getPiezasBlancas().add(peon);
        }
        Pieza torre1 = new Torre("blanco",new Coordenada(0,0));
        Pieza torre2 = new Torre("blanco",new Coordenada(0,7));
        casillas[0][0] = torre1;
        casillas[0][7] = torre2;
        Pieza caballo1 = new Caballo("blanco",new Coordenada(0,1));
        Pieza caballo2 = new Caballo("blanco",new Coordenada(0,6));
        casillas[0][1] = caballo1;
        casillas[0][6] = caballo2;        
        Pieza alfir2 = new Alfir("blanco",new Coordenada(0,2));
        Pieza alfir1 = new Alfir("blanco",new Coordenada(0,5));
        casillas[0][2] = alfir1;
        casillas[0][5] = alfir2;
        Pieza rey = new Rey("blanco",new Coordenada(0,3));
        Pieza reina = new Reina("blanco",new Coordenada(0,4));
        casillas[0][3] = rey;
        casillas[0][4] = reina;
        //las agrega a la lista
        getPiezasBlancas().add(torre1);
        getPiezasBlancas().add(torre2);
        getPiezasBlancas().add(caballo1);
        getPiezasBlancas().add(caballo2);
        getPiezasBlancas().add(alfir1);
        getPiezasBlancas().add(alfir2);
        getPiezasBlancas().add(rey);
        getPiezasBlancas().add(reina);
        
        //negras
        for (int i = 0; i < 8; i++) {
            Pieza peon = new Peon("negro",new Coordenada(6,i));
            casillas[6][i] = peon;
            getPiezasNegras().add(peon);
        }
        Pieza torre3 = new Torre("negro",new Coordenada(7,0));
        Pieza torre4= new Torre("negro",new Coordenada(7,7));
        casillas[7][0]= torre3;
        casillas[7][7]= torre4;         
        Pieza caballo3= new Caballo("negro",new Coordenada(7,1));
        Pieza caballo4 = new Caballo("negro",new Coordenada(7,6));
        casillas[7][1] = caballo3;
        casillas[7][6] = caballo4;
        Pieza alfir3 = new Alfir("negro",new Coordenada(7,2));
        Pieza alfir4 = new Alfir("negro",new Coordenada(7,5));
        casillas[7][2] = alfir3;
        casillas[7][5] = alfir4;
        Pieza rey2= new Rey("negro",new Coordenada(7,3));
        Pieza reina2= new Reina("negro",new Coordenada(7,4));
        casillas[7][3] = rey2;
        casillas[7][4] = reina2;
        //las agrega a la lista
        getPiezasNegras().add(torre3);
        getPiezasNegras().add(torre4);
        getPiezasNegras().add(caballo3);
        getPiezasNegras().add(caballo4);
        getPiezasNegras().add(alfir3);
        getPiezasNegras().add(alfir4);
        getPiezasNegras().add(rey2);
        getPiezasNegras().add(reina2);
    }
    public void eliminarPieza(Pieza pieza) {
        if (pieza.getColor().equals("blanco")) {
            getPiezasBlancas().remove(pieza);
        }else {
            getPiezasNegras().remove(pieza);
    }
}
        
    
    /**
     * @param c
     * @return the boolean
     */
    public boolean hayPieza(Coordenada c) {
        return casillas[c.getFila()][c.getColumna()] != null;
    }
    public Pieza getCasilla(Coordenada c){
        return casillas[c.getFila()][c.getColumna()];
    }

    /**
     * @return the piezasBlancas
     */
    public ArrayList<Pieza> getPiezasBlancas() {
        return piezasBlancas;
    }

    /**
     * @return the piezasNegras
     */
    public ArrayList<Pieza> getPiezasNegras() {
        return piezasNegras;
    }
    public void setPiezaEnCasilla(Coordenada c, Pieza pieza) {
        casillas[c.getFila()][c.getColumna()] = pieza;
        if (pieza != null){
            pieza.setPosicion(c);
        }
    }

    public void quitarPiezaEnCasilla(Coordenada c) {
        casillas[c.getFila()][c.getColumna()] = null;
    }
    
}

