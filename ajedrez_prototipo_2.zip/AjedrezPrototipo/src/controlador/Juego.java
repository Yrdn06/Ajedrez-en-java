/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
import mundo.Jugador;
import mundo.Tablero;
import interfaz.Interfaz;
/**
 *
 * @author yudyp
 */
public class Juego {
    private Jugador jugadorBlanco;
    private Jugador jugadorNegro;
    private Tablero tablero;
    private Interfaz interfazApp;
    public Juego(){
        jugadorBlanco = new Jugador("jugador blanco","blanco");
        jugadorNegro = new Jugador("jugador negro","negro");
        interfazApp = new Interfaz();
        tablero =  new Tablero();
    }

    /**
     * @return the jugadorBlanco
     */
    public Jugador getJugadorBlanco() {
        return jugadorBlanco;
    }

    /**
     * @return the jugadorNegro
     */
    public Jugador getJugadorNegro() {
        return jugadorNegro;
    }

    /**
     * @return the tablero
     */
    public Tablero getTablero() {
        return tablero;
    }

    /**
     * @return the interfazApp
     */
    public Interfaz getInterfazApp() {
        return interfazApp;
    }
    public void iniciar(){
        while(true){
            //turno blanco
            System.out.println("turno de blanco");
            interfazApp.imprimirTablero(tablero);
            jugadorBlanco.mover_pieza(interfazApp, tablero);
            //turno negro
            System.out.println("turno de negro");
            interfazApp.imprimirTablero(tablero);
            jugadorNegro.mover_pieza(interfazApp, tablero);
        }
    }
            
    public static void main(String[] args) {
        Juego partida = new Juego();
        partida.iniciar();
        
    }
    
}
