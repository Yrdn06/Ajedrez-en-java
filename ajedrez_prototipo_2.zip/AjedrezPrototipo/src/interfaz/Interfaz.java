/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaz;
import java.util.Scanner;
import mundo.Tablero;
import mundo.Coordenada;
import java.util.InputMismatchException;
/**
 *
 * @author yudyp
 */
public class Interfaz {
    Scanner sc;
    public Interfaz(){
        sc = new Scanner(System.in);
    }
    public Coordenada pedirCoordenada(){
        while(true){    
            try {
                int fila;
                String columna;
                System.out.print("ingrese la fila(1 - 8):");
                fila = sc.nextInt();
                fila = fila-1;
                sc.nextLine();
                System.out.print("ingrese la columna (A - H):");
                columna = sc.nextLine().trim().toUpperCase();
                int columna_conv;
                columna_conv = switch (columna) {
                    case "A" -> 0;
                    case "B" -> 1;
                    case "C" -> 2;
                    case "D" -> 3;
                    case "E" -> 4;
                    case "F" -> 5;
                    case "G" -> 6;
                    case "H" -> 7;
                    default -> -1;
                };
                if (fila >= 0 && fila<=7 && columna_conv != -1){
                    Coordenada c= new Coordenada(fila,columna_conv);
                    return c;
                }
                else{
                    System.out.println("la coordenada ingresada esta fuera de rango");
                }
            }
            catch (InputMismatchException e){
                System.out.println("los valores ingresados estan mal, vuelva a ingresar");  
                sc.nextLine();
            }
        }
    }
    public void imprimirTablero(Tablero tablero){
        System.out.println("---------------------------------------------------------------------");
        System.out.print("."+"\t");
        for (int i = 0; i < 8; i++) {
            char letraFila = (char) ('A' + i); 
            System.out.print(letraFila + "\t");
        }
        System.out.println("");
        for (int i = 0; i < 8; i++) {
            System.out.print((i+1) + "\t");
            for (int j = 0; j < 8; j++) {
                Coordenada c = new Coordenada(i,j);
                if (tablero.getCasilla(c) != null){
                    System.out.print(tablero.getCasilla(c).toString() + "\t");
                }else{
                    System.out.print("." + "\t");
                }
            }
            System.out.println("");    
            
        }
        System.out.println("---------------------------------------------------------------------");
    }
}
