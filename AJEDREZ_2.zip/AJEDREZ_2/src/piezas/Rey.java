package piezas;

/**
 *
 * @author Usuario
 */
import ajedrez_2.Tablero;
import java.awt.image.BufferedImage;

public class Rey extends Pieza {
    public Rey(Tablero tablero, int columnas, int filas, boolean esBlanca) {
        super(tablero);
        this.columnas = columnas;
        this.filas = filas;
        this.xPos = columnas * tablero.tileSize;
        this.yPos = filas * tablero.tileSize;
        this.esBlanca = esBlanca;
        this.name = "Rey";

        if (sheet != null) {
            int spriteX = 0 * sheetScale;
            int spriteY = esBlanca ? 0 : sheetScale;

            this.sprite = sheet.getSubimage(
                    spriteX,
                    spriteY,
                    sheetScale,
                    sheetScale
            ).getScaledInstance(tablero.tileSize, tablero.tileSize, BufferedImage.SCALE_SMOOTH);
        }
    }

    @Override
    public boolean esMovimientoValido(int columnaDestino, int filaDestino) {
        int deltaColumna = Math.abs(columnaDestino - this.columnas);
        int deltaFila = Math.abs(filaDestino - this.filas);

        if (deltaColumna <= 1 && deltaFila <= 1 && (deltaColumna + deltaFila > 0)) {
            return !esAliadaEnDestino(columnaDestino, filaDestino);
        }

        return false;
    }
}