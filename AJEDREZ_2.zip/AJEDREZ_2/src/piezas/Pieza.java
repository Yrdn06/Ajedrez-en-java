package piezas;

/**
 *
 * @author Usuario
 */
import ajedrez_2.Tablero;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class Pieza {
    public int columnas, filas;
    public int xPos, yPos;
    public int xPosAnterior, yPosAnterior;

    public boolean esBlanca;
    public String name;
    public int value;

    BufferedImage sheet;
    protected int sheetScale;
    Image sprite;
    Tablero tablero;

    {
        try {
            InputStream is = getClass().getResourceAsStream("/pieces.png");

            if (is == null) {
                is = getClass().getClassLoader().getResourceAsStream("pieces.png");
            }

            if (is != null) {
                sheet = ImageIO.read(is);
                sheetScale = sheet.getWidth() / 6;  // CAMBIADO: ahora son 6 columnas
                System.out.println("✓ Imagen cargada correctamente");
                System.out.println("Sheet width: " + sheet.getWidth() + ", height: " + sheet.getHeight());
                System.out.println("SheetScale: " + sheetScale);
            } else {
                System.err.println("ERROR: pieces.png no encontrado");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Pieza(Tablero tablero) {
        this.tablero = tablero;
    }

    public boolean esMovimientoValido(int columnaDestino, int filaDestino) {
        return false;
    }

    public boolean hayPiezaEnDestino(int columnaDestino, int filaDestino) {
        for (Pieza pieza : tablero.piezaList) {
            if (pieza.columnas == columnaDestino && pieza.filas == filaDestino) {
                return true;
            }
        }
        return false;
    }

    public boolean esAliadaEnDestino(int columnaDestino, int filaDestino) {
        for (Pieza pieza : tablero.piezaList) {
            if (pieza.columnas == columnaDestino && pieza.filas == filaDestino) {
                return pieza.esBlanca == this.esBlanca;
            }
        }
        return false;
    }

    public void mover(int columnaDestino, int filaDestino) {
        xPosAnterior = xPos;
        yPosAnterior = yPos;
        this.columnas = columnaDestino;
        this.filas = filaDestino;
        this.xPos = columnaDestino * tablero.tileSize;
        this.yPos = filaDestino * tablero.tileSize;
    }

    public void paint(Graphics2D g2d) {
        if (sprite != null) {
            g2d.drawImage(sprite, xPos, yPos, null);
        }
    }
}