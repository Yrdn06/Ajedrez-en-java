package piezas;

/**
 *
 * @author Usuario
 */
import ajedrez_2.Tablero;
import java.awt.image.BufferedImage;

public class Caballo extends Pieza {
    public Caballo(Tablero tablero, int columnas, int filas, boolean esBlanca) {
        super(tablero);
        this.columnas = columnas;
        this.filas = filas;
        this.xPos = columnas * tablero.tileSize;
        this.yPos = filas * tablero.tileSize;
        this.esBlanca = esBlanca;
        this.name = "Caballo";

        if (sheet != null) {
            int spriteX = 3 * sheetScale;
            int spriteY = esBlanca ? 0 : sheetScale;

            this.sprite = sheet.getSubimage(
                    spriteX,
                    spriteY,
                    sheetScale,
                    sheetScale
            ).getScaledInstance(tablero.tileSize, tablero.tileSize, BufferedImage.SCALE_SMOOTH);
        }
    }

    @Override
    public boolean esMovimientoValido(int columnaDestino, int filaDestino) {
        int deltaColumna = Math.abs(columnaDestino - this.columnas);
        int deltaFila = Math.abs(filaDestino - this.filas);

        //2 casillas en una dirección y 1 en la otra
        if ((deltaColumna == 2 && deltaFila == 1) || (deltaColumna == 1 && deltaFila == 2)) {
            return !esAliadaEnDestino(columnaDestino, filaDestino);
        }

        return false;
    }
}