package piezas;

/**
 *
 * @author Usuario
 */
import ajedrez_2.Tablero;
import java.awt.image.BufferedImage;

public class Peon extends Pieza {
    public Peon(Tablero tablero, int columnas, int filas, boolean esBlanca) {
        super(tablero);
        this.columnas = columnas;
        this.filas = filas;
        this.xPos = columnas * tablero.tileSize;
        this.yPos = filas * tablero.tileSize;
        this.esBlanca = esBlanca;
        this.name = "Peon";

        if (sheet != null) {
            int spriteX = 5 * sheetScale;
            int spriteY = esBlanca ? 0 : sheetScale;

            this.sprite = sheet.getSubimage(
                    spriteX,
                    spriteY,
                    sheetScale,
                    sheetScale
            ).getScaledInstance(tablero.tileSize, tablero.tileSize, BufferedImage.SCALE_SMOOTH);
        }
    }

    @Override
    public boolean esMovimientoValido(int columnaDestino, int filaDestino) {
        int direccion = esBlanca ? 1 : -1; //las blancas avanzan hacia abajo, negras hacia arriba


        if (columnaDestino == this.columnas && filaDestino == this.filas + direccion) {
            return !hayPiezaEnDestino(columnaDestino, filaDestino); //Se mueve si no hay nada adelante
        }

        //come en diagonal
        if (Math.abs(columnaDestino - this.columnas) == 1 && filaDestino == this.filas + direccion) {
            return hayPiezaEnDestino(columnaDestino, filaDestino) && !esAliadaEnDestino(columnaDestino, filaDestino);
        }

        return false;
    }
}
