package piezas;

/**
 *
 * @author Usuario
 */
import ajedrez_2.Tablero;
import java.awt.image.BufferedImage;

public class Torre extends Pieza {
    public Torre(Tablero tablero, int columnas, int filas, boolean esBlanca) {
        super(tablero);
        this.columnas = columnas;
        this.filas = filas;
        this.xPos = columnas * tablero.tileSize;
        this.yPos = filas * tablero.tileSize;
        this.esBlanca = esBlanca;
        this.name = "Torre";

        if (sheet != null) {
            int spriteX = 4 * sheetScale;
            int spriteY = esBlanca ? 0 : sheetScale;

            this.sprite = sheet.getSubimage(
                    spriteX,
                    spriteY,
                    sheetScale,
                    sheetScale
            ).getScaledInstance(tablero.tileSize, tablero.tileSize, BufferedImage.SCALE_SMOOTH);
        }
    }

    @Override
    public boolean esMovimientoValido(int columnaDestino, int filaDestino) {
        if (columnaDestino != this.columnas && filaDestino != this.filas) {
            return false;
        }

        if (columnaDestino == this.columnas && filaDestino == this.filas) {
            return false;
        }

        // que no haya nada delante
        int deltaColumna = Integer.compare(columnaDestino - this.columnas, 0);
        int deltaFila = Integer.compare(filaDestino - this.filas, 0);

        int columnaActual = this.columnas + deltaColumna;
        int filaActual = this.filas + deltaFila;

        while (columnaActual != columnaDestino || filaActual != filaDestino) {
            if (hayPiezaEnDestino(columnaActual, filaActual)) {
                return false; // hay una pieza bloqueando el camino
            }
            columnaActual += deltaColumna;
            filaActual += deltaFila;
        }

        return !esAliadaEnDestino(columnaDestino, filaDestino);
    }
}
