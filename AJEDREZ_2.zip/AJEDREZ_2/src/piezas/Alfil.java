package piezas;
import ajedrez_2.Tablero;
import java.awt.image.BufferedImage;
/**
 *
 * @author Usuario
 */


public class Alfil extends Pieza {
    public Alfil(Tablero tablero, int columnas, int filas, boolean esBlanca) {
        super(tablero);
        this.columnas = columnas;
        this.filas = filas;
        this.xPos = columnas * tablero.tileSize;
        this.yPos = filas * tablero.tileSize;
        this.esBlanca = esBlanca;
        this.name = "Alfil";

        if (sheet != null) {
            // Alfil está en la columna 2
            int spriteX = 2 * sheetScale;
            int spriteY = esBlanca ? 0 : sheetScale;

            this.sprite = sheet.getSubimage(
                    spriteX,
                    spriteY,
                    sheetScale,
                    sheetScale
            ).getScaledInstance(tablero.tileSize, tablero.tileSize, BufferedImage.SCALE_SMOOTH);
        }
    }

    @Override
    public boolean esMovimientoValido(int columnaDestino, int filaDestino) {
        int deltaColumna = Math.abs(columnaDestino - this.columnas);
        int deltaFila = Math.abs(filaDestino - this.filas);

        //se mueve 2 casillas en diagonal pero saltando
        if (deltaColumna == 2 && deltaFila == 2) {
            //salta sobre la casilla intermedia, no necesita verificar obstáculos
            return !esAliadaEnDestino(columnaDestino, filaDestino);
        }

        return false;
    }
}
