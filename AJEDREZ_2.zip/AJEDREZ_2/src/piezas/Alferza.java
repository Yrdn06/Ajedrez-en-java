package piezas;

/**
 *
 * @author Usuario
 */
import ajedrez_2.Tablero;
import java.awt.image.BufferedImage;

public class Alferza extends Pieza {
    public Alferza(Tablero tablero, int columnas, int filas, boolean esBlanca) {
        super(tablero);
        this.columnas = columnas;
        this.filas = filas;
        this.xPos = columnas * tablero.tileSize;
        this.yPos = filas * tablero.tileSize;
        this.esBlanca = esBlanca;
        this.name = "Alferza";

        if (sheet != null) {
            int spriteX = 1 * sheetScale;
            int spriteY = esBlanca ? 0 : sheetScale;

            this.sprite = sheet.getSubimage(
                    spriteX,
                    spriteY,
                    sheetScale,
                    sheetScale
            ).getScaledInstance(tablero.tileSize, tablero.tileSize, BufferedImage.SCALE_SMOOTH);
        }
    }

    @Override
    public boolean esMovimientoValido(int columnaDestino, int filaDestino) {
        int deltaColumna = Math.abs(columnaDestino - this.columnas);
        int deltaFila = Math.abs(filaDestino - this.filas);


        if (deltaColumna == 1 && deltaFila == 1) {// se mueve una casilla en diagonal
            return !esAliadaEnDestino(columnaDestino, filaDestino);
        }

        return false;
    }
}
