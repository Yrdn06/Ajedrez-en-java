package ajedrez_2;

/**
 *
 * @author Usuario
 */
import piezas.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

public class Tablero extends JPanel implements MouseListener, MouseMotionListener {
    public int tileSize = 85;
    int columnas = 8;
    int filas = 8;

    public ArrayList<Pieza> piezaList = new ArrayList<>();

    Pieza piezaSeleccionada;
    boolean turnoBlancas = true;
    boolean juegoTerminado = false;
    public String mensajeVictoria = "";

    private java.util.function.Consumer<Boolean> turnoListener;
    private java.util.function.Consumer<String> estadoJuegoListener;

    public Tablero(){
        this.setPreferredSize(new Dimension(columnas*tileSize, filas*tileSize));
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        addPiezas();
    }

    public void setTurnoListener(java.util.function.Consumer<Boolean> listener) {
        this.turnoListener = listener;
    }

    public void setEstadoJuegoListener(java.util.function.Consumer<String> listener) {
        this.estadoJuegoListener = listener;
    }

    private void actualizarEstadoJuego() {
        if (estadoJuegoListener != null) {
            if (juegoTerminado) {
                estadoJuegoListener.accept("JUEGO TERMINADO");
            } else if (reyEnJaque(turnoBlancas)) {
                estadoJuegoListener.accept("¡REY EN JAQUE!");
            } else {
                estadoJuegoListener.accept("");
            }
        }
    }

    public void addPiezas(){
        piezaList.add(new Torre(this, 0, 0, true));
        piezaList.add(new Caballo(this, 1, 0, true));
        piezaList.add(new Alfil(this, 2, 0, true));
        piezaList.add(new Rey(this, 3, 0, true));
        piezaList.add(new Alferza(this, 4, 0, true));
        piezaList.add(new Alfil(this, 5, 0, true));
        piezaList.add(new Caballo(this, 6, 0, true));
        piezaList.add(new Torre(this, 7, 0, true));

        for(int c = 0; c < 8; c++){
            piezaList.add(new Peon(this, c, 1, true));
        }

        for(int c = 0; c < 8; c++){
            piezaList.add(new Peon(this, c, 6, false));
        }

        piezaList.add(new Torre(this, 0, 7, false));
        piezaList.add(new Caballo(this, 1, 7, false));
        piezaList.add(new Alfil(this, 2, 7, false));
        piezaList.add(new Rey(this, 3, 7, false));
        piezaList.add(new Alferza(this, 4, 7, false));
        piezaList.add(new Alfil(this, 5, 7, false));
        piezaList.add(new Caballo(this, 6, 7, false));
        piezaList.add(new Torre(this, 7, 7, false));
    }

    public Pieza obtenerPieza(int columna, int fila) {
        for (Pieza pieza : piezaList) {
            if (pieza.columnas == columna && pieza.filas == fila) {
                return pieza;
            }
        }
        return null;
    }

    public Rey encontrarRey(boolean esBlanco) {
        for (Pieza pieza : piezaList) {
            if (pieza instanceof Rey && pieza.esBlanca == esBlanco) {
                return (Rey) pieza;
            }
        }
        return null;
    }

    public boolean reyEnJaque(boolean esBlanco) {
        Rey rey = encontrarRey(esBlanco);
        if (rey == null) return false;

        for (Pieza pieza : piezaList) {
            if (pieza.esBlanca != esBlanco) {
                if (pieza.esMovimientoValido(rey.columnas, rey.filas)) {
                    return true;
                }
            }
        }
        return false;
    }


    public boolean esMovimientoLegal(Pieza pieza, int columnaDestino, int filaDestino) {

        if (!pieza.esMovimientoValido(columnaDestino, filaDestino)) {
            return false;
        }


        int columnaOriginal = pieza.columnas;
        int filaOriginal = pieza.filas;
        Pieza piezaCapturada = obtenerPieza(columnaDestino, filaDestino);


        if (piezaCapturada != null) {
            piezaList.remove(piezaCapturada);
        }
        pieza.columnas = columnaDestino;
        pieza.filas = filaDestino;


        boolean reyEnJaqueDespuesDeMovimiento = reyEnJaque(pieza.esBlanca);


        pieza.columnas = columnaOriginal;
        pieza.filas = filaOriginal;
        if (piezaCapturada != null) {
            piezaList.add(piezaCapturada);
        }


        return !reyEnJaqueDespuesDeMovimiento;
    }


    public boolean tieneMovimientosLegales(boolean esBlanco) {
        for (Pieza pieza : piezaList) {
            if (pieza.esBlanca == esBlanco) {
                for (int f = 0; f < filas; f++) {
                    for (int c = 0; c < columnas; c++) {
                        if (esMovimientoLegal(pieza, c, f)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public int contarPiezas(boolean esBlanco) {
        int contador = 0;
        for (Pieza pieza : piezaList) {
            if (pieza.esBlanca == esBlanco && !(pieza instanceof Rey)) {
                contador++;
            }
        }
        return contador;
    }

    public void verificarCondicionesDeVictoria() {

        if (reyEnJaque(turnoBlancas) && !tieneMovimientosLegales(turnoBlancas)) {
            juegoTerminado = true;
            mensajeVictoria = (turnoBlancas ? "NEGRAS" : "BLANCAS") + " ganan por JAQUE MATE!";
            System.out.println(mensajeVictoria);
            actualizarEstadoJuego();
            repaint();
            return;
        }


        if (!reyEnJaque(turnoBlancas) && !tieneMovimientosLegales(turnoBlancas)) {
            juegoTerminado = true; //rey ahogado
            mensajeVictoria = (turnoBlancas ? "NEGRAS" : "BLANCAS") + " ganan por AHOGADO!";
            System.out.println(mensajeVictoria);
            actualizarEstadoJuego();
            repaint();
            return;
        }


        int piezasBlancas = contarPiezas(true);
        int piezasNegras = contarPiezas(false);

        if (piezasBlancas == 0) {
            juegoTerminado = true;
            mensajeVictoria = "NEGRAS ganan - Rey blanco DESNUDO!";
            System.out.println(mensajeVictoria);
            actualizarEstadoJuego();
            repaint();
            return;
        }

        if (piezasNegras == 0) {
            juegoTerminado = true;
            mensajeVictoria = "BLANCAS ganan - Rey negro DESNUDO!";
            System.out.println(mensajeVictoria);
            actualizarEstadoJuego();
            repaint();
            return;
        }

        // Actualizar estado normal (jaque o nada)
        actualizarEstadoJuego();
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;


        for (int f = 0; f < filas; f++){
            for(int c = 0; c < columnas; c++){
                g2d.setColor((c + f)%2 == 0 ? new Color(227, 198, 181) : new Color(157, 105, 53));
                g2d.fillRect(c * tileSize, f*tileSize, tileSize, tileSize);
            }
        }


        if (reyEnJaque(turnoBlancas) && !juegoTerminado) {
            Rey rey = encontrarRey(turnoBlancas);
            if (rey != null) {
                g2d.setColor(new Color(255, 0, 0, 150));
                g2d.fillRect(rey.columnas * tileSize, rey.filas * tileSize, tileSize, tileSize);
            }
        }


        if (piezaSeleccionada != null && !juegoTerminado) {
            g2d.setColor(new Color(68, 180, 57, 100));
            g2d.fillRect(piezaSeleccionada.columnas * tileSize, piezaSeleccionada.filas * tileSize, tileSize, tileSize);


            for (int f = 0; f < filas; f++) {
                for (int c = 0; c < columnas; c++) {
                    if (esMovimientoLegal(piezaSeleccionada, c, f)) {
                        Pieza piezaEnDestino = obtenerPieza(c, f);
                        if (piezaEnDestino != null && piezaEnDestino.esBlanca != piezaSeleccionada.esBlanca) {
                            g2d.setColor(new Color(255, 0, 0, 150));
                            g2d.fillRect(c * tileSize, f * tileSize, tileSize, tileSize);
                        } else {
                            g2d.setColor(new Color(68, 180, 57, 180));
                            int circuloSize = tileSize / 4;
                            g2d.fillOval(
                                    c * tileSize + tileSize / 2 - circuloSize / 2,
                                    f * tileSize + tileSize / 2 - circuloSize / 2,
                                    circuloSize,
                                    circuloSize
                            );
                        }
                    }
                }
            }
        }


        for(Pieza pieza : piezaList){
            pieza.paint(g2d);
        }


        if (juegoTerminado) {
            g2d.setColor(new Color(0, 0, 0, 200));
            g2d.fillRect(0, (filas * tileSize) / 2 - 40, columnas * tileSize, 80);

            g2d.setColor(new Color(255, 215, 0));
            g2d.setFont(new Font("Arial", Font.BOLD, 24));
            FontMetrics fm = g2d.getFontMetrics();
            int textoX = (columnas * tileSize - fm.stringWidth(mensajeVictoria)) / 2;  //gano
            g2d.drawString(mensajeVictoria, textoX, (filas * tileSize) / 2 + 10);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (juegoTerminado) return;

        int columna = e.getX() / tileSize;
        int fila = e.getY() / tileSize;

        if (fila < 0 || fila >= filas || columna < 0 || columna >= columnas) return;

        if (piezaSeleccionada != null) {

            if (esMovimientoLegal(piezaSeleccionada, columna, fila)) {
                realizarMovimiento(columna, fila);
                return;
            }
        }

        Pieza piezaEnCasilla = obtenerPieza(columna, fila);

        if (piezaEnCasilla != null && piezaEnCasilla.esBlanca == turnoBlancas) {
            piezaSeleccionada = piezaEnCasilla;
            repaint();
        } else {
            piezaSeleccionada = null;
            repaint();
        }
    }

    private void realizarMovimiento(int columna, int fila) {
        Pieza capturada = obtenerPieza(columna, fila);
        if (capturada != null && capturada.esBlanca != piezaSeleccionada.esBlanca) {
            piezaList.remove(capturada);
            System.out.println("Capturada: " + capturada.name + " " + (capturada.esBlanca ? "blanca" : "negra"));
        }

        piezaSeleccionada.mover(columna, fila);


        if (piezaSeleccionada instanceof Peon) {
            int filaPromocion = piezaSeleccionada.esBlanca ? 7 : 0;
            if (piezaSeleccionada.filas == filaPromocion) {
                piezaList.remove(piezaSeleccionada);
                piezaList.add(new Alferza(this, columna, fila, piezaSeleccionada.esBlanca));
            }
        }

        turnoBlancas = !turnoBlancas;
        piezaSeleccionada = null;

        if (turnoListener != null) {
            turnoListener.accept(turnoBlancas);
        }

        verificarCondicionesDeVictoria();
        repaint();
    }

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseDragged(MouseEvent e) {}

    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mouseMoved(MouseEvent e) {}
    
}