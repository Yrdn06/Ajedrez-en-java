package ajedrez_2;

/**
 *
 * @author Usuario
 */
public class Input {
    public int x;
    public int y;
}