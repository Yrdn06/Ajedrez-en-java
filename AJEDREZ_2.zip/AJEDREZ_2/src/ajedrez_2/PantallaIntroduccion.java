package ajedrez_2;

/**
 *
 * @author Usuario
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PantallaIntroduccion extends JPanel {
    private JFrame frameActual;

    public PantallaIntroduccion(JFrame frame) {
        this.frameActual = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(40, 40, 40));

        JPanel panelContenido = new JPanel();
        panelContenido.setLayout(new BoxLayout(panelContenido, BoxLayout.Y_AXIS));
        panelContenido.setBackground(new Color(40, 40, 40));
        panelContenido.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        JLabel titulo = new JLabel("AJEDREZ");
        titulo.setFont(new Font("Serif", Font.BOLD, 48));
        titulo.setForeground(Color.YELLOW);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelContenido.add(titulo);

        panelContenido.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel subtitulo = new JLabel("El Ajedrez Ancestral de Persia");
        subtitulo.setFont(new Font("Serif", Font.ITALIC, 24));
        subtitulo.setForeground(new Color(200, 200, 200));
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelContenido.add(subtitulo);

        panelContenido.add(Box.createRigidArea(new Dimension(0, 30)));

        panelContenido.add(Box.createRigidArea(new Dimension(0, 40)));

        JButton botonComenzar = new JButton("COMENZAR PARTIDA");
        botonComenzar.setFont(new Font("Arial", Font.BOLD, 24));
        botonComenzar.setBackground(Color.LIGHT_GRAY);
        botonComenzar.setForeground(Color.BLACK);
        botonComenzar.setFocusPainted(false);
        botonComenzar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonComenzar.setMaximumSize(new Dimension(300, 60));
        botonComenzar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        botonComenzar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarJuego();
            }
        });

        panelContenido.add(botonComenzar);
        panelContenido.add(Box.createRigidArea(new Dimension(0, 30)));

        JScrollPane scrollPane = new JScrollPane(panelContenido);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBorder(null);

        add(scrollPane, BorderLayout.CENTER);
    }

    private void agregarSeccion(JPanel panel, String titulo, String contenido) {
        JLabel labelTitulo = new JLabel(titulo);
        labelTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        labelTitulo.setForeground(Color.YELLOW);
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(labelTitulo);

        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JTextArea textArea = new JTextArea(contenido);
        textArea.setFont(new Font("Arial", Font.PLAIN, 16));
        textArea.setForeground(new Color(220, 220, 220));
        textArea.setBackground(new Color(40, 40, 40));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        textArea.setFocusable(false);
        textArea.setAlignmentX(Component.LEFT_ALIGNMENT);
        textArea.setMaximumSize(new Dimension(800, Integer.MAX_VALUE));

        panel.add(textArea);
        panel.add(Box.createRigidArea(new Dimension(0, 25)));
    }

    private void iniciarJuego() {
        frameActual.getContentPane().removeAll();

        JPanel panelPrincipal = new JPanel(new BorderLayout());

        Tablero tablero = new Tablero();
        panelPrincipal.add(tablero, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.Y_AXIS));
        panelBotones.setBackground(Color.DARK_GRAY);
        panelBotones.setPreferredSize(new Dimension(180, 680));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        panelBotones.add(Box.createRigidArea(new Dimension(0, 20)));

        JLabel labelTurno = new JLabel("BLANCAS");
        labelTurno.setFont(new Font("Times New Roman", Font.BOLD, 20));
        labelTurno.setForeground(Color.WHITE);
        labelTurno.setAlignmentX(Component.CENTER_ALIGNMENT);
        labelTurno.setHorizontalAlignment(SwingConstants.CENTER);
        panelBotones.add(labelTurno);

        panelBotones.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel labelTurnoTexto = new JLabel("Turno");
        labelTurnoTexto.setFont(new Font("Arial", Font.PLAIN, 14));
        labelTurnoTexto.setForeground(Color.LIGHT_GRAY);
        labelTurnoTexto.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelBotones.add(labelTurnoTexto);

        panelBotones.add(Box.createRigidArea(new Dimension(0, 20)));


        JLabel labelEstado = new JLabel("");
        labelEstado.setFont(new Font("Arial", Font.BOLD, 14));
        labelEstado.setForeground(Color.RED);
        labelEstado.setAlignmentX(Component.CENTER_ALIGNMENT);
        labelEstado.setHorizontalAlignment(SwingConstants.CENTER);
        panelBotones.add(labelEstado);

        panelBotones.add(Box.createVerticalGlue());

        JButton btnReglas = new JButton("Reglas");
        btnReglas.setFont(new Font("Serif", Font.BOLD, 14));
        btnReglas.setFocusPainted(false);
        btnReglas.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnReglas.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnReglas.setMaximumSize(new Dimension(120, 100));
        btnReglas.setPreferredSize(new Dimension(120, 100));

        btnReglas.addActionListener(e -> mostrarReglas());

        panelBotones.add(btnReglas);
        panelBotones.add(Box.createVerticalGlue());

        tablero.setTurnoListener((esBlancas) -> {
            labelTurno.setText(esBlancas ? "BLANCAS" : "NEGRAS");
        });


        tablero.setEstadoJuegoListener((estado) -> {
            labelEstado.setText(estado);


            if (estado.equals("JUEGO TERMINADO")) {
                String mensajeVictoria = tablero.mensajeVictoria;
                JOptionPane.showMessageDialog(
                        frameActual,
                        mensajeVictoria,
                        "¡Juego Terminado!",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }
        });

        panelPrincipal.add(panelBotones, BorderLayout.EAST);

        frameActual.add(panelPrincipal);

        frameActual.setSize(900, 720);
        frameActual.setLocationRelativeTo(null);

        frameActual.revalidate();
        frameActual.repaint();
    }

    public static void mostrarReglas(){
        String reglas = """
                === REGLAS ===
                
                MOVIMIENTO DE LAS PIEZAS:
                
                • REY: Se mueve 1 casilla en cualquier dirección
                
                • ALFERZA (Reina): Se mueve solo 1 casilla en diagonal
                
                • TORRE: Se mueve en línea recta horizontal/vertical
                
                • CABALLO: Se mueve en "L" y puede saltar piezas
                
                • ALFIL: Se mueve exactamente 2 casillas en diagonal, saltando
                
                • PEÓN: Se mueve 1 casilla adelante, captura en diagonal.
                  Solo promociona a Alferza
                
                PARA GANAR:
                1. JAQUE MATE al rey enemigo
                2. AHOGADO (sin movimientos legales, gana el oponente)
                3. REY DESNUDO (capturar todas las piezas excepto el rey)
                
                DIFERENCIAS CON AJEDREZ MODERNO:
                • No hay enroque
                • Peones no avanzan 2 casillas al inicio
                """;

        JTextArea textArea = new JTextArea(reglas);
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 500));

        JOptionPane.showMessageDialog(null, scrollPane,
                "Reglas", JOptionPane.INFORMATION_MESSAGE);
    }
}