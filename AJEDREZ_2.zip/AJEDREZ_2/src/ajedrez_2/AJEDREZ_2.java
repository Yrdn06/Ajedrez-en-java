package ajedrez_2;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Usuario
 */
public class AJEDREZ_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        JFrame frame = new JFrame(" Ajedrez ");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(Color.BLACK);

        PantallaIntroduccion pantallaIntro = new PantallaIntroduccion(frame);
        frame.add(pantallaIntro);

        frame.setSize(1000, 800);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}